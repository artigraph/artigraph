from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from arti import (
    Fingerprint,
    InputFingerprints,
    Storage,
    StoragePartition,
    StoragePartitionSnapshots,
)
from arti.internal.models import Model
from arti.storage._internal import parse_spec, spec_to_wildcard

if TYPE_CHECKING:
    from gcsfs import GCSFileSystem


def gcs_file_system() -> GCSFileSystem:
    try:
        from gcsfs import GCSFileSystem
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "GCS support requires the `all` extra: `pip install 'arti[all]'`"
        ) from exc
    return GCSFileSystem()


class _GCSMixin(Model):
    bucket: str
    path: str

    @property
    def qualified_path(self) -> str:
        return f"{self.bucket}/{self.path}"


class GCSFilePartition(_GCSMixin, StoragePartition):
    def compute_content_fingerprint(self) -> Fingerprint:
        # TODO: GCSFileSystem needs to be injected somehow
        info = gcs_file_system().info(f"{self.bucket}/{self.path}")
        # Prefer md5Hash if available
        return Fingerprint.from_string(
            str(info["md5Hash"] if "md5Hash" in info else info["crc32c"])
        )


class GCSFile(_GCSMixin, Storage[GCSFilePartition]):
    path: str = str(
        Path("{graph_name}")
        / "{path_tags}"
        / "{names}"
        / "{partition_key_spec}"
        / "{input_fingerprint}"
        / "{name}.{extension}"
    )

    def discover_partitions(
        self, input_fingerprints: InputFingerprints = InputFingerprints()
    ) -> StoragePartitionSnapshots:
        # NOTE: The bucket/path must *already* have any graph tags resolved, otherwise they will be try to be parsed as
        # partition keys.
        spec = f"{self.bucket}/{self.path}"
        wildcard = spec_to_wildcard(spec, self.key_types)
        # TODO: GCSFileSystem needs to be injected somehow
        paths = gcs_file_system().glob(wildcard)
        path_metadata = parse_spec(
            set(paths), spec=spec, key_types=self.key_types, input_fingerprints=input_fingerprints
        )
        return tuple(
            self.generate_partition(
                input_fingerprint=input_fingerprint, partition_key=partition_key
            ).snapshot()
            for input_fingerprint, partition_key in path_metadata.values()
        )
